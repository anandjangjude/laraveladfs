<!-- Common Header -->
<div id="header">
    <div id="logo">
        <h1><a href="#">ADFS AUTH DEMO</a></h1>
        <h2><a href="#">Authenticate application using Active Directory Federation Services</a></h2>
    </div>
</div>
