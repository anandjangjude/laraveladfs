<li id="links">
    <h2>Learn More</h2>
    <ul>
        <li>
            <p><a href="http://en.wikipedia.org/wiki/Active_Directory_Federation_Services" target="_blank">What is ADFS?</a></p>
        </li>
        <li>
            <p><a href="http://en.wikipedia.org/wiki/WS-Federation" target="_blank">WS-Federation</a></p>
        </li>
        <li>
            <p><a href="http://technet.microsoft.com/en-us/library/cc736690%28WS.10%29.aspx" target="_blank">ADFS @ Technet</a></p>
        </li>
    </ul>
</li>
