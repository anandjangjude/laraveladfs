<!-- Common footer -->
<div id="footer">
    <p id="legal">Copyright &copy; 2010 Schakra Inc. All Rights Reserved.</p>
</div>


