<li id="links">
    <h2>Solution Downloads</h2>
    <ul>
        <li>
            <p><a href="#">ADFS Authentication for Joomla</a></p>
        </li>
        <li>
            <p><a href="#">ADFS Authentication for Drupal</a></p>
        </li>
    </ul>
</li>
