<?php
/**
 * Description of adfsuserdetails
 */
class AdfsUserDetails {
    
    public $nameIdentifier;
    
    public $nameIdentifierFormat;
    
    public $attributes;
}
?>
